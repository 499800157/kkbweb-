export default class S1{
    constructor(){
        this.name = "契约之盾";
        this.ico = "./sources/skills/16610.png";
    }
}