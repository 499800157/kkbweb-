class S3{
    constructor(){
        this.name = "空中支援"
        this.ico = "./sources/skills/11230.png"
    }
}


export default S3