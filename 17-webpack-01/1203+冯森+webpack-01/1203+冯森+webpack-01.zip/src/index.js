import fn1 from "./fn.js"
import logo from "./images/logo.png"
import "./css/css.css"
console.log(fn1)



let img = new Image()
img.src = logo;
document.body.appendChild(img);




