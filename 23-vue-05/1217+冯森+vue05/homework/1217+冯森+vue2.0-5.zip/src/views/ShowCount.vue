<template>
  <div>
      show count : {{ count }}
  </div>
</template>

<script>
export default {
    props:["count"],
    
    mounted(){
        
    },
    computed:{
        // count:
    }
}
</script>

<style>

</style>