<template>
  <Circle ></Circle>
</template>

<script>
import Circle from "./components/Circle";
import { onMounted, onUnmounted } from "vue";
import { game, getRootContainer } from "./game/index";
export default {
  name: "App",
  components: {
    Circle,
  },
  setup() {
    let arrow = true;
    function move() {
      if (arrow) {
        getRootContainer().children[0].x++;
        if (getRootContainer().children[0].x > 750) {
          arrow = false;
        }
        } else {
        getRootContainer().children[0].x--;
        if (getRootContainer().children[0].x <= 0) {
          arrow = true;
        }
      }
    }
    onMounted(() => {
      game.ticker.add(move);
    });
    onUnmounted(() => {
      game.ticker.remove(move);
    });

  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
