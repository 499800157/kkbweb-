<template>
    <circle 
    @click="fn"
    :interactive="true"
    ></circle>    
</template>

<script>
export default {
    setup(props, { emit }) {
        console.log("circle")
        function fn(){
            console.log("111")
            emit("handleClick","123")
        }
        return {
           fn 
        }
    }
}
</script>

<style>

</style>