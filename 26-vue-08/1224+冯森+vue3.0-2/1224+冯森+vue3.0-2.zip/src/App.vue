<template>
  <Circle 
    @handleClick="toRemove"
  ></Circle>
</template>

<script>
import Circle from "./components/Circle";
import { onMounted, onUnmounted } from "vue";
import { game, getRootContainer } from "./game/index";
export default {
  name: "App",
  components: {
    Circle,
  },
  setup() {
    let arrow = true;
    function handleTicker() {
      if (arrow) {
        getRootContainer().children[0].x++;
        if (getRootContainer().children[0].x > 500) {
          arrow = false;
        }
      } else {
        getRootContainer().children[0].x--;
        if (getRootContainer().children[0].x <= 0) {
          arrow = true;
        }
      }
      console.log("handleTicker")
    }

    onMounted(() => {
      game.ticker.add(handleTicker);
    });
    onUnmounted(() => {
      game.ticker.remove(handleTicker);
    });

    function toRemove(){
      console.log("remove")
    }
    return {
      toRemove
    };
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
