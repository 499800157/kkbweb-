export default class Skin3{
    constructor(){
        this.name = "皮肤三";
        this.ico = "./sources/heros/yase3.png";
        this.img = "./sources/skins/301662.png"
    }
}