<template>
  <div>
    <button :disabled="$attrs.disabled">btn</button>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
