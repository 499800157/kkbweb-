import Vue from "vue";

// event bus
export const bus = new Vue();
