console.log("我是b.js");
define({
    myname:"bjs"
})
