export default function() {
    console.lo('fn');
}