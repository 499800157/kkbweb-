import fn from './fn.js';
import './css/css.css';

// fn();

document.onclick = function() {
    fn();
}