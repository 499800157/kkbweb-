import axios from 'axios';

export default async function() {
    console.log('fn!!!!');

    // let rs = await axios({
    //     // url: 'http://localhost:8787/api/info'
    //     url: '/api/info'
    // });

    // console.log('rs', rs);
}