// api
// 命名上的规范
// axios
import http from "../http";

export function apiLogin({ username, password }) {
  return (
    http
      // /api/login
      // /login
      .post("/login", {
        username,
        password
      })
  );
}

export function apiGetPhotos() {
  return http.get("/getPhotos");
}

export function apiUpload(file) {
  const formData = new FormData();
  formData.append("img", file);
  return http.post("/upload", formData).then(res => {
    console.log(res);
  });
}
