<template>
  <div class="uploadPhotoItem">
    <!-- <span class="myProgress">
      <span class="plan"></span>
      30%
    </span> -->
    <img :src="imgSrc" />
    <span class="pictureName">
      {{ item.name }}
    </span>
  </div>
</template>

<script>
export default {
  // file -> show
  props: ["item"],
  data() {
    return {
      imgSrc: ""
    };
  },
  mounted() {
    // file -> base64 url
    // 异步的 所以必须要在 onload 内获取到结果值
    const fileReader = new FileReader();
    fileReader.onload = () => {
      this.imgSrc = fileReader.result;
    };
    fileReader.readAsDataURL(this.item);
  }
};
</script>

<style></style>
