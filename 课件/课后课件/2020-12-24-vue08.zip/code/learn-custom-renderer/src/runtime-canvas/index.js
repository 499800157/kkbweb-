import { createRenderer } from "vue";
import { Graphics } from "pixi.js";
const renderer = createRenderer({
  // 创建一个元素
  // 抽象的接口 函数
  createElement(type) {
    console.log(type);
    // 已经有了足够的信息去创建元素了
    // 在这里 我们就需要调用 canvas 的api 了
    // todo 需要调用 canvas 的 api
    //
    // const element = document.createElement(type);
    // return element;
    let element;
    switch (type) {
      case "rect":
        element = new Graphics();
        element.beginFill(0xff0000);
        element.drawRect(0, 0, 500, 500);
        element.endFill();

        break;
      case "circle":
        element = new Graphics();
        element.beginFill(0xffff00);
        element.drawCircle(0, 0, 50);
        element.endFill();
        break;
    }

    return element;
  },
  patchProp(el, key, prevValue, nextValue) {
    switch (key) {
      case "x":
        el.x = nextValue;

        break;
      case "y":
        el.y = nextValue;

        break;

      default:
        break;
    }
  },

  // 插入
  insert(el, parent) {
    console.log(el, parent);
    parent.addChild(el);
  },
});

export function createApp(rootComponent) {
  return renderer.createApp(rootComponent);
}
