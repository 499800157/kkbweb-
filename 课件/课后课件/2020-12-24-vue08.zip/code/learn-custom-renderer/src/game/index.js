import { Application } from "pixi.js";

//init
const game = new Application({
  width: 750,
  height: 1080,
});

// canvas
document.body.append(game.view);

export function getRootContainer() {
  return game.stage;
}
