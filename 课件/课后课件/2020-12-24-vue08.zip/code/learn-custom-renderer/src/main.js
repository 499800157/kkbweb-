// import { createApp, createRenderer, render } from "vue";
// import { createRenderer } from "vue";
import { createApp } from "./runtime-canvas";
import App from "./App.vue";
import { getRootContainer } from "./game";

// 容器
// canvas
// pixijs game.stage
createApp(App).mount(getRootContainer());

// {
//     type:"div",
//     children:"123"
// }
// const renderer = createRenderer({
//   // 创建一个元素
//   createElement(type) {
//     console.log(type);
//     // 已经有了足够的信息去创建元素了
//     // 在这里 我们就需要调用 canvas 的api 了
//     // todo 需要调用 canvas 的 api
//     //
//     const element = document.createElement(type);
//     return element;
//   },

//   // 插入
//   insert(el, parent) {
//     console.log(el, parent);
//   },
// });
// console.log(renderer);

// 1. App
// 2. canvas 容器
// renderer.createApp(App).mount();

// createRenderer 就是用来告诉 vue 我要自定义渲染平台的api了
// createApp(App).mount("#app");
// console.log(App);
// // App -> 根组件
// // template -> render() 会返回一个 vnode （vdom）-> dom 元素呢？

// // vnode 描述了一些信息 -》 都是为了创建一个 dom 元素
// // dom 元素的信息
// console.log(App.render());

// const vnode = {
//   type: "div",
//   children: "123",
// };

// // document api

// 创建一个元素
// const element = document.createElement(vnode.type);
// 添加一个孩子节点
// element.innerText = vnode.children;
// 设置一个文字
// 添加到容器内
// element -> 添加到哪里？
// #app -> 根容器
