// import { createApp } from 'vue'// import App from './App.vue'

// createApp(App).mount('#app')

import {
  Application,
  Graphics,
  Sprite,
  Texture,
  Text,
  TextStyle,
  Container,
} from "pixi.js";

const game = new Application({
  width: 500,
  height: 500,
});

console.log(game);
document.body.append(game.view);

// 查文档都知道
//创建一个矩形
const rect = new Graphics();
rect.beginFill(0xff0000);
rect.drawRect(0, 0, 50, 50);
rect.endFill();
rect.x = 50;
rect.y = 50;

// 概念其实都差不多 ，就是 api 的使用方式有点变化
// dom api 区别大吗？
import logo from "./assets/logo.png";

// 创建图片
const img = new Sprite();
img.interactive = true;
// src
img.texture = Texture.from(logo);

const text = new Text("heihei");
text.style = new TextStyle({
  fill: "red",
});
text.x = 380;

// 一直去改变它的 x 坐标
// setInterval(() => {
//
// }, interval);
// 帧循环
img.on("pointertap", () => {
  game.ticker.remove(handleTicker);
});
const handleTicker = () => {
  img.x++;
};
game.ticker.add(handleTicker);

// 移除
// game.ticker.remove(handleTicker);

// 创建容器
const box = new Container();
box.addChild(text);
box.addChild(img);
box.x = 250

// game.stage.addChild(text);
// game.stage.addChild(img);
game.stage.addChild(box);
game.stage.addChild(rect);
