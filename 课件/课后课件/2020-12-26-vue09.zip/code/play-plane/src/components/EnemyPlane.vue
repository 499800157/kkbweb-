<template>
  <container>
    <sprite :texture="enemyImg"></sprite>
  </container>
</template>

<script>
import { reactive, onMounted, onUnmounted } from "vue";
import enemyImg from "../assets/enemy.png";
import { game } from "../game";
export default {
  setup() {
    return {
      enemyImg,
    };
  },
};

export function useEnemyPlane() {
  // todo 自动创建敌军
  const width = 398;
  const height = 207;
  const enemyPlanes = reactive([
    {
      x: 55,
      y: 55,
      width,
      height,
    },
    // {
    //   x: 90,
    //   y: 120,
    //   width,
    //   height,
    // },
  ]);

  // eslint-disable-next-line no-unused-vars
  function move() {
    const speed = 5;
    const handleTicker = () => {
      enemyPlanes.forEach((enemy, index) => {
        enemy.y += speed;

        if (enemy.y >= 1280) {
          // 怎么移除呢？
          // mvvm
          enemyPlanes.splice(index, 1);
        }
      });
    };

    onMounted(() => {
      game.ticker.add(handleTicker);
    });

    onUnmounted(() => {
      game.ticker.remove(handleTicker);
    });
  }

//   move();

  return {
    enemyPlanes,
  };
}
</script>
