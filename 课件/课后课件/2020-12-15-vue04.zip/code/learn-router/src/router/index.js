// 入口
import VueRouter from "vue-router";
import Vue from "vue";
import Home from "../pages/Home.vue";
// import About from "../pages/About.vue";
import ClassPage from "../pages/Class.vue";
// import ClassPageA from "../pages/ClassA.vue";
import User from "../pages/User.vue";
import Foo from "../pages/Foo.vue";
import Posts from "../pages/Posts.vue";
// 小步走的概念
console.log(VueRouter);

// vueRouter -> 插件
// use -> 眼熟？
// 中间件 安装 -> 插件 -> 函数
// 注册了组件
// router-view
// router-link
Vue.use(VueRouter);
// 组件
// 页面级别的组件
// 通用的组件

// 路由的核心
// url -> 页面
// about -> about 页面
// /     -> / 页面

// koa -> 路由
// 请求过来 url -> 匹配对应的处理函数

// url -> 视图
// 概念都差不多

// routes -》先匹配到了谁，就是谁
const router = new VueRouter({
  mode: "history",
  routes: [
    {
      path: "/home",
      redirect: "/",
    },
    {
      name: "home",
      path: "/",
      alias: "/heihei", // 小明 李明 都代表一个人
      component: Home,
      //   components: {
      //     default: Home,
      //     foo: Foo,
      //     posts: Posts,
      //   },
      beforeEnter(to, from, next) {
        console.log("before-enter");
        console.log(to);
        console.log(from);
        console.log(next);
        next();
      },
      meta: {
        isAuth: false,
      },
    },
    {
      // 可以不用变动的
      // 不易变动的
      name: "class",
      // path -> 很有可能会变动的
      path: "/className/:id",
      component: ClassPage,
      props: (route) => {
        console.log(route);
        // -》 id
        // 给它加工加工
        return {
          id: route.params.id + "------------",
        };
      },
    },
    {
      name: "user",
      path: "/user",
      component: User,
      children: [
        {
          // /user/posts
          path: "posts",
          component: Posts,
        },

        {
          path: "foo",
          component: Foo,
        },
      ],
      meta: {
        isAuth: true,
      },
    },

    // {
    //   path: "/class/1",
    //   component: ClassPageA,
    // },
  ],
});

// next 熟悉不？
// koa
// 权限的问题
// 有些路由是需要控制的
// 判断一下，是否可以访问 鉴权
router.beforeEach((to, from, next) => {
  console.log("before-each");
  console.log(to);
  console.log(from);
  console.log(next);
  //   next();

  if (to.meta.isAuth) {
    // 说明需要权限
    // 是否登录
    // 给它调转到登录页面
    // push/ replace
    next({
      name: "class",
    });
  } else {
    next();
  }
});

router.afterEach((to, from) => {
  console.log("afterEach");
  console.log(to, from);
});

export default router;
