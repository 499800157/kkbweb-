<template>
  <div>
    About
  </div>
</template>

<script>
export default {};
</script>

<style></style>
