export function fn1() {
    console.log('fn1');
}