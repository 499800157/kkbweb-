import {fn2} from './2.js';
import kkb from './data/kkb.txt';
// import logo from './images/logo.png';
// import css from './css/css.css';
import './css/css.css';

fn2();
// fn2();

console.log('kkb', kkb);
// console.log('logo', logo);

// let img = new Image()
// img.src = logo;
// document.body.appendChild(img);

// console.log('css', css.toString());

// let style = document.createElement('style');
// style.innerHTML = css.toString();
// document.head.appendChild(style);