import {fn2} from './2.js';

fn2();