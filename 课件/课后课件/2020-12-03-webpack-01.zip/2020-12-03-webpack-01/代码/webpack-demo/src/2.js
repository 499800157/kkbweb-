export function fn2() {
    console.log('222222');
}