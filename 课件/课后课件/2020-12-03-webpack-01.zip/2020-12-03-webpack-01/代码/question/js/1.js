fn1();

function fn1() {
    console.log('我是1.js的fn1函数');
}

x = 100;
console.log('x', x);