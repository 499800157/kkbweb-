const a = require('./a.js');
module.exports.c = 'kkb' + a.s;