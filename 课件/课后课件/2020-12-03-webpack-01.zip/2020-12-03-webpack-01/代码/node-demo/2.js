

module.exports.b = 10000;

// console.log('module2', module);