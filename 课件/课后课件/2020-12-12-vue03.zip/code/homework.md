### 暗号

### 知识点

- vue-cli
- sfc
- jest
- Vue-test-utils

### 任务题目

1. 参加直播课，学习时长需>=60%

2. 给 Button 组件添加测试
   1. 使用 vue-cli 创建项目
   2. 测试 button slot 显示的内容
   3. 测试 button 点击的时候发出 click 自定义事件
   4. 测试设置 disabled 属性后，click 事件不能发出
3. 通过标准：完成以上所有任务及要求，方可通过。备注：允许有逻辑错误，不允许有语法错误
