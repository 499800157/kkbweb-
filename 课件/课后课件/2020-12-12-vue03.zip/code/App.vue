<template>
  <div>
    <ul>
      <li>{{ count }}</li>
    </ul>
  </div>
</template>

<script>
// js
export default {
  data() {
    return {
      count: 1,
    };
  },
};
</script>

<style>
//
</style>
