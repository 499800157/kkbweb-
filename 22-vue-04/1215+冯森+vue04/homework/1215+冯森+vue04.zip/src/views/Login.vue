<template>
    <div>
        <h2>login页面</h2>
        <router-link to = "/home">go home</router-link>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style  scoped>

</style>