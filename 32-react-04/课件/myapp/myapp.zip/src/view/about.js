function AboutPage() {
  return <h1>关于视图</h1>
}

export default AboutPage;