function IndexPage() {
  return <h1>首页</h1>
}

export default IndexPage;