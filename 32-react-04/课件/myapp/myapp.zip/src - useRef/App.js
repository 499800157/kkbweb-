import { useState } from "react";
import Child from "./Child";
function App() {
  return <div>
      <Child />
  </div>;
}

export default App;
