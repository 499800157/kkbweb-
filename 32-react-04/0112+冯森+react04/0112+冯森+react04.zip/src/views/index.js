
function IndexPage() {
    return (
        <>
            <img src={require("../img/img4.png").default} className="banner" />
            <div className="wrap">
                <img src={require("../img/img_1.png").default} />
                <img src={require("../img/img_2.png").default} />
            </div>
        </>
    )
}

export default IndexPage

